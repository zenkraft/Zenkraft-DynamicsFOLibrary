﻿

function Get-AzureAccessTokenMSI
{
    # Get an access token for the MSI
    $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F' -Headers @{Metadata="true"}
    $content =$response.Content | ConvertFrom-Json
    $access_token = $content.access_token
    
    return $access_token
}

function Get-AzureApplicationGateway
{
    $access_token = Get-AzureAccessTokenMSI
    $subscriptionId = Get-AzureSubscriptionIdForVM -access_token $access_token
    $resourceGroupName = Get-AzureResourceGroupNameForVM -access_token $access_token -subscriptionId $subscriptionId
    $applicationGatewayName = Get-AzureApplicationGatewayNameForVM -access_token $access_token -subscriptionId $subscriptionId -resourceGroupName $resourceGroupName

    $apInfoRest = (Invoke-WebRequest -Uri https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Network/applicationGateways/"$applicationGatewayName"?api-version=2018-02-01 -Method GET -ContentType "application/json" -Headers @{ Authorization ="Bearer $access_token"}).content
    $apInfoJson = $apInfoRest | ConvertFrom-Json
    return $apInfoJson
}

function Set-AzureApplicationGateway([PSCustomObject] $apInfoJson)
{
    $access_token = Get-AzureAccessTokenMSI
    $subscriptionId = Get-AzureSubscriptionIdForVM -access_token $access_token
    $resourceGroupName = Get-AzureResourceGroupNameForVM -access_token $access_token -subscriptionId $subscriptionId
    $applicationGatewayName = Get-AzureApplicationGatewayNameForVM -access_token $access_token -subscriptionId $subscriptionId -resourceGroupName $resourceGroupName

    $apInfoRest = $apInfoJson | ConvertTo-Json -Depth 99
    $response = (Invoke-WebRequest -Uri https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Network/applicationGateways/"$applicationGatewayName"?api-version=2018-02-01 -Method PUT -ContentType "application/json" -Headers @{ Authorization ="Bearer $access_token"} -Body $apInfoRest ).content
    return $response 
}

function Set-AzureApplicationGatewayToDrain
{
    $apInfoJson = Get-AzureApplicationGateway
    $apInfoJson.properties.backendHttpSettingsCollection.Item(0).properties.connectionDraining.enabled = 'True'
    $apInfoJson.properties.backendHttpSettingsCollection.Item(0).properties.connectionDraining.drainTimeoutInSec = 3600
    $apInfoJson.properties.backendHttpSettingsCollection.Item(1).properties.connectionDraining.enabled = 'True'
    $apInfoJson.properties.backendHttpSettingsCollection.Item(1).properties.connectionDraining.drainTimeoutInSec = 3600
    $response = Set-AzureApplicationGateway -apInfoJson $apInfoJson
}

function Set-AzureApplicationGatewayToUnDrain
{
    $apInfoJson = Get-AzureApplicationGateway
    $apInfoJson.properties.backendHttpSettingsCollection.Item(0).properties.connectionDraining.enabled = 'False'
    $apInfoJson.properties.backendHttpSettingsCollection.Item(0).properties.connectionDraining.drainTimeoutInSec = 3600
    $apInfoJson.properties.backendHttpSettingsCollection.Item(1).properties.connectionDraining.enabled = 'False'
    $apInfoJson.properties.backendHttpSettingsCollection.Item(1).properties.connectionDraining.drainTimeoutInSec = 3600
    $response = Set-AzureApplicationGateway -apInfoJson $apInfoJson
}

function removeVMfromApplicationGatewayBackendPool([string] $vmIP)
{
    $apInfoJson = Get-AzureApplicationGateway
    $BackendIpAddress = [System.Collections.ArrayList] $apInfoJson.properties.backendAddressPools.properties.backendAddresses
    $BackendIpAddress = $BackendIpAddress | Where-Object{$_.ipAddress -ne $vmIP }
    $apInfoJson.properties.backendAddressPools.properties.backendAddresses = [System.Object[]] $BackendIpAddress
    $response = Set-AzureApplicationGateway -apInfoJson $apInfoJson
}

function addVMfromApplicationGatewayBackendPool([string] $vmIP)
{
    $apInfoJson = Get-AzureApplicationGateway
    $BackendIpAddress = [System.Collections.ArrayList] $apInfoJson.properties.backendAddressPools.properties.backendAddresses
    $newBackendIpAddress = $BackendIpAddress | Where-Object{$_.ipAddress -eq $vmIP }    

    if($newBackendIpAddress.Count -eq 0)
    {
        $MyIpAddress = New-Object PSObject
        Add-Member -InputObject $MyIpAddress -MemberType NoteProperty -Name ipAddress -Value $vmIP
        $BackendIpAddress.Add($MyIpAddress)    
    }
    $apInfoJson.properties.backendAddressPools.properties.backendAddresses = [System.Object[]] $BackendIpAddress
    $response = Set-AzureApplicationGateway -apInfoJson $apInfoJson
}


function drainAosVM
{
    Set-AzureApplicationGatewayToDrain  
    $MyIpAddress = getMyVMIP
    removeVMfromApplicationGatewayBackendPool -vmIP $MyIpAddress
}

function unDrainAosVM
{
    Set-AzureApplicationGatewayToUnDrain
    $MyIpAddress = getMyVMIP
    addVMfromApplicationGatewayBackendPool -vmIP $MyIpAddress
}

function getMyVMIP ()
{
    $ip=get-WmiObject Win32_NetworkAdapterConfiguration|Where {$_.Ipaddress.length -gt 1} 

    return $ip.ipaddress[0] 
}

function Get-AzureSubscriptionIdForVM ([string]  $access_token )
{
    $subscriptionInfoRest = (Invoke-WebRequest -Uri https://management.azure.com/subscriptions?api-version=2018-02-01 -Method GET -ContentType "application/json" -Headers @{ Authorization ="Bearer $access_token"}).content
    $subscriptionInfo = $subscriptionInfoRest | ConvertFrom-Json
    return $subscriptionInfo.value.subscriptionId

}

function Get-AzureResourceGroupNameForVM ([string]  $access_token, [string] $subscriptionId )
{
    $resourceGroupInfoRest = (Invoke-WebRequest -Uri https://management.azure.com/subscriptions/$subscriptionId/resourcegroups?api-version=2018-02-01 -Method GET -ContentType "application/json" -Headers @{ Authorization ="Bearer $access_token"}).content
    $resourceGroupInfo = $resourceGroupInfoRest | ConvertFrom-Json
    return $resourceGroupInfo.value.Name
}

function Get-AzureApplicationGatewayNameForVM ([string]  $access_token, [string] $subscriptionId, [string] $resourceGroupName  )
{
    $applicationGatewayInfoRest = (Invoke-WebRequest -Uri https://management.azure.com/subscriptions/$subscriptionId/resourcegroups/$resourceGroupName/providers/Microsoft.Network/applicationGateways?api-version=2018-02-01 -Method GET -ContentType "application/json" -Headers @{ Authorization ="Bearer $access_token"}).content
    $applicationGatewayInfo = $applicationGatewayInfoRest | ConvertFrom-Json
    return $applicationGatewayInfo.value.Name
}


Export-ModuleMember -Function drainAosVM
Export-ModuleMember -Function unDrainAosVM


# SIG # Begin signature block
# MIIj0QYJKoZIhvcNAQcCoIIjwjCCI74CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDsUZB6MYDQKFkX
# t3TJ/qFOPtdo5cBdW73oE9lEBpGom6CCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVpjCCFaICAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCB+TAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgRKEpN69Q
# 3LA72QIWOpu02Srt/qu8oXt3Bq5lagJDbeMwgYwGCisGAQQBgjcCAQwxfjB8oF6A
# XABBAHUAdABvAFUAcABnAHIAYQBkAGUAQwBvAG4AZgBpAGcAQQBvAHMAUwBlAHIA
# dgBpAGMAZQBQAGwAYQB0AGYAbwByAG0AVQBwAGQAYQB0AGUAMQAuAHAAcwAxoRqA
# GGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQCx9Q9+
# eAy61TixQAuqDCkwz14xAX0eX3Q5ebIUYNvv56e2Pd6WMiM/3aOb3HxZB1wYqX8O
# jxKQNa0fCfEPzSvxE42qE7F4Zun/0hDRKhLsvJP+7Pjcoz0m+3HWn8gBL/ifNv5l
# Vf8zgaijLQHm52E2hXj0gWcFrd8QvmqeI689JlqRw2VI0Lz3Q0f3KpmOjDqUX0Ct
# wybLQfBW2DpPDkL7xAAjwNYgVTCMzekF1ZB87Qvt7p/NmZoExNawxyZvxkSsof7p
# fQtRtdiXE5BkLSTlsSRZQ2uNhJrLzstgOOJjKISSqx8C7itLwAfUdKefkTtFVWmR
# JsBWuBlV234GMy0moYIS5TCCEuEGCisGAQQBgjcDAwExghLRMIISzQYJKoZIhvcN
# AQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCCAVEGCyqGSIb3DQEJEAEE
# oIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIB8j
# i/2xqR6sqbYWd/B4vpQNTZG9Klt0F48AoIJeeLUNAgZcXFLJoSgYEzIwMTkwMjE1
# MTUzMTUyLjAxOFowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQI
# EwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExp
# bWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJBRDQtNEI5Mi1GQTAxMSUw
# IwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2aWNloIIOPDCCBPEwggPZ
# oAMCAQICEzMAAADXr1puwKo9zrYAAAAAANcwDQYJKoZIhvcNAQELBQAwfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIzMjAyNjUwWhcNMTkxMTIz
# MjAyNjUwWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsT
# JE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMd
# VGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQDdiIha4gkM4bDfHbchZGKOIuASSGISvvwK0tIAkL7hIbtG1r0X+Ybzt0lI
# 3Hcy6C/ozxZIHPLtDUdLX2+E6XtGj8xHw6Q1xJWQbxtsMvdLoszc51rkwPIIBfGz
# FMQB7iYhH9U1QPGGVRWEiMD3ZGdpkDkH7q8nPMgqzVjTdkHWynVaqdNMjst9lhKU
# BVHsptgAjOoNdcwX/Xz9CRxetlzi6hzLuFuZ47rnFIjqMPf7GnkbzdwvUXvoiMdP
# 7PVATtW1M0l7Ny1VxcpTnUBrIlqaIl9O3pgggjoPLLfZj+exulZi8K/E5ZVHJ3YI
# Z7LMUvQgTNPLs6eN4yJvwW5yuWC9AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU37in
# VSf/92m8M1ZjNmtNKaDqVTgwHwYDVR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/
# BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQsFAAOCAQEATAto
# UsT5ALWyTHGwnNqeeoO4CCjRB7i0OLPeQcjv7JWTA9Qf0OzONpepqV8vwxElyOMY
# NMRi8MQEVckDi1DpwqzJAh8WSImjaBAg9h0F9YwOuRtGDWF3r6BE72QOiJ8KtWRU
# FF2vPszCKQK2Zon9gu3OGivAmmBy+5LnC8kq75c7uKM4/Zr1LrbCinPF7GZBCGkR
# wQzRlLQp81N9eCmOBKpDdPjesqHGPb8MAk50HA1lme/zRAn6RAkF4+DWOL/rNu5f
# Lh51PjxgQPn3gUT4Q/ah1dR9yoPN0lcNnPPx9vAJ5v2smw0n1ajgw4FOvCqbDLj8
# qs12l6t4xqT617ltMDCCBnEwggRZoAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcN
# AQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAw
# BgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEw
# MB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCp
# HQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVT
# JwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q
# 6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h
# /EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+
# 79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4
# zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAd
# BgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgw
# FoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0
# XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0G
# CCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BT
# L2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBs
# AGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4IC
# AQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efw
# eL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt0
# 70IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQi
# PM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93F
# SguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4a
# rgRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoGig+JFrphpxHLmtgOR5qA
# xdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEHpJM692VHeOj4qEir995y
# fmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaY
# LeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL
# 32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4
# L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJEqGCAs4wggI3AgEBMIH4
# oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIaAxUAzTZ24jTRpyU2peuc
# TVbl/F0HEa2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAN
# BgkqhkiG9w0BAQUFAAIFAOAQtGEwIhgPMjAxOTAyMTUxMTQ1MzdaGA8yMDE5MDIx
# NjExNDUzN1owdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA4BC0YQIBADAKAgEAAgIV
# RwIB/zAHAgEAAgIR4TAKAgUA4BIF4QIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgor
# BgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUA
# A4GBAFfIDMMk/bb7V05Qa0n0vyiA8vQZahvHVnEZmWIWVXsG69YrepCJVGC2NB7O
# wSylXuqNErtlAFJ6QM2hXIOQWVgi0xE4K47hPR47X3hQfc+cHniX7iLJhYXHSQsv
# jFYMZuZ4101zYQJOKPV4eSWPT7JpMHvykdU3bYi8E+NwWT1bMYIDDTCCAwkCAQEw
# gZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAADXr1puwKo9zrYA
# AAAAANcwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAvBgkqhkiG9w0BCQQxIgQgtlCL6dk5iE8zhfNm6oGcrD4Yx6o5CdhZsoQy
# ALbLTNIwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCljmAMJw9BHv3eSih0
# +yhBcs7IauKTg/VixBFGziTjODCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwAhMzAAAA169absCqPc62AAAAAADXMCIEIImQiOvF+C2R7tSGWMJc
# g6QKqPk6O/NBGFOjjiKdJYekMA0GCSqGSIb3DQEBCwUABIIBAALKnYffIJtb1R5l
# +s5USB0YS6RXdKntwqDj5zBRBJjluDApv45CRE0+lj6gmotkpgMUyVcCVQD1FI5b
# VMEpwyLTx9osEw7bZmfjoaCLFpMD0QAvnTbaq53oRBz5fgEPoV6mo6Zfr01EC2fp
# zN2hh6hGMF3QsHiXBR7kPg5Dui5oY20x/GYGA++kSugRiPTdO2NDlwMspHoNPyw9
# NosGTo9LS7svt+MDceyoNXpNXPBihqf3QZVhCMbin+Yp7ouzghAZQhsj2FA3ppT8
# XMMRMqq980EErGY86cxev2kTNUCVnbibYy3bqo/+vNiVu2ddcOBPv2Fu1zOGQFYK
# 3PNrRis=
# SIG # End signature block
